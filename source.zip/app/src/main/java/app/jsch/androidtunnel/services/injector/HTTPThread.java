package app.jsch.androidtunnel.services.injector;

import android.content.SharedPreferences;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import app.jsch.androidtunnel.logs.AppLogManager;

/** Copies traffic between the local JSch proxy and the injected socket. */
public class HTTPThread extends Thread {
    private final Socket incoming;
    private final Socket outgoing;
    private final boolean clientToServer;
    private boolean responseHandled = false;
    private final ByteArrayOutputStream responsePending = new ByteArrayOutputStream();

    public HTTPThread(Socket socket, Socket socket2, boolean clientToServer) {
        incoming = socket;
        outgoing = socket2;
        this.clientToServer = clientToServer;
        setDaemon(true);
    }

    @Override public void run() {
        try {
            InputStream from = incoming.getInputStream();
            OutputStream to = outgoing.getOutputStream();
            byte[] buffer = new byte[32768];
            int count;
            while ((count = from.read(buffer)) != -1) {
                if (clientToServer || responseHandled) {
                    to.write(buffer, 0, count);
                    to.flush();
                } else {
                    forwardServerResponse(buffer, count, to);
                }
            }
            from.close();
            to.close();
        } catch (Exception ignored) {
            closeQuietly();
        }
    }

    /**
     * HTTP Custom hides the injector's intermediate 403 before JSch sees it.
     * Buffer only through the first HTTP header, replace the status with 200,
     * discard the response body, and pass all bytes after the header through
     * untouched as the SSH stream.
     */
    private void forwardServerResponse(byte[] data, int length, OutputStream to) throws Exception {
        responsePending.write(data, 0, length);
        byte[] all = responsePending.toByteArray();
        String text = new String(all, StandardCharsets.ISO_8859_1);
        int headerEnd = text.indexOf("\r\n\r\n");
        if (headerEnd < 0 && responsePending.size() < 65536) return;

        if (text.startsWith("HTTP/")) {
            int firstEnd = text.indexOf("\r\n");
            String first = firstEnd >= 0 ? text.substring(0, firstEnd) : text;
            AppLogManager.addToLog("<b>" + first + "</b>");
            if (headerEnd >= 0) {
                String statusLine = text.substring(0, firstEnd >= 0 ? firstEnd : text.length());
                String protocol = statusLine.split(" ", 2)[0];
                byte[] rest = java.util.Arrays.copyOfRange(all, headerEnd + 4, all.length);
                to.write((protocol + " 200 OK\r\n\r\n").getBytes(StandardCharsets.ISO_8859_1));
                if (rest.length > 0) to.write(rest);
            } else {
                to.write(all);
            }
            to.flush();
        } else {
            to.write(all);
            to.flush();
        }
        responsePending.reset();
        responseHandled = true;
    }

    private void closeQuietly() {
        try { incoming.close(); } catch (Exception ignored) {}
        try { outgoing.close(); } catch (Exception ignored) {}
    }
}
